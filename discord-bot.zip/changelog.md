# Changelog

## [1.0.0] - 2024-12-13
### Added
- Comando pra avisar os players q a sesião iniciou

### Testando
- Testando o bglh pra mandar os update do bot automáticamente

- - - - - - - - - -

## [1.0.0v2] - 2024-12-13
### Fixed
- Bot marcando usuário inexisteste nos updates
- Pouco espaço pra marcação do cargo

- - - - - - - - - -

## [1.0.0v3] - 2024-12-19
### Fixed
- Arquivo inteiro de changelog sendo enviado (esqueci q agr é o bot q faz meu trabalho sujo)

- - - - - - - - - -

## [1.0.0v4] - 2024-12-19
### Fixed
- Changelog sendo enviada de forma errada

- - - - - - - - - -

## [1.0.1] - 2024-12-19
### Changed
- Foi mudado como o aviso que a sessão iria iniciar era interpretado, agr ele escolhe uma entre 30 opções pra manter a fluídes do bglh

- - - - - - - - - -

## [1.0.1v2] - 2024-12-19
### Fixed
- Ajustes no código

- - - - - - - - - -

## [1.0.1v3] - 2024-12-19
### Fixed
- JSON sendo bugado como sempre

- - - - - - - - - -

## [1.0.2] - 2024-12-19
### Changed
- (Admin Only) Foi mudado a dinâmica de como funciona o comando de iniciar e terminar sesião, fundindo a mecânica de abri e fechar a sesião em um unico comando

- - - - - - - - - -

## [1.0.2v2] - 2024-12-19
### Fixed
- (Admin Only) /togglesession agora funciona corretamente (esqueci da porra de uma variável)

- - - - - - - - - -

## [1.0.3] - 2024-12-19
### Added
- Compatibilidade com a mesa "Desordem"

- - - - - - - - - -

## [1.0.3v2] - 2024-12-19
### Fixed
- (Admins Only) Opção "Desordem" não estava aparecendo

- - - - - - - - - -

## [1.1.0] - 2025-03-05
### Added (only authorized users)
- "/executar_comando"

### Added (moderation only)
- "/mutar"
- "/desmutar"
- "/mover"

### Removed
- "/togglesessao"

- - - - - - - - - -

## [1.1.1] - 2025-03-05
### Added
- Tocador de Músicas

- - - - - - - - - -

## [1.1.2] - 2025-03-06
### Added
- Jokenpô (kkkkkkkk)

### Removed
- Tocador de músicas (tava foda pra fazer funcionar)

- - - - - - - - - -

## [1.2.0] - 2025-03-07

### Added

- Função para rodar dados

- - - - - - - - - -

## [1.3.0] - 2025-03-24

🔥 **El big update '0'** 🔥

### 🆕 Adicionado

✅ **Comandos de Moderação:**

- **`/mutar`** _(Admin only)_ – Muta todos os membros de um canal de voz, um usuário ou um cargo específico.
- **`/desmutar`** _(Admin only)_ – Desmuta todos os membros de um canal de voz ou apenas um usuário/cargo específico.
- **`/mover`** _(Admin only)_ – Move todos os membros de um canal de voz para outro.

🎵 **Comandos de Áudio:**

- **`/tocar [arquivo]`** – Toca um áudio do repositório no canal de FFFFFvoz.
- **`/fila`** – Exibe a fila de reprodução de áudios.
- **`/pular`** – Pula para o próximo áudio na fila.
- **`/parar`** – Para a reprodução e limpa a fila.

### ❌ Removido

- **`/executar_comando`** – Comando genérico de execução de código foi descontinuado.

- - - - - - - - - -

## [1.4.1] - 2025-03-28

🔥 **A atualização do caos chegou!** 🔥

### 🆕 Adicionado

🎲 **Comandos de Diversão:**
- **`/roleta`** – Escolhe uma opção aleatória dentre as fornecidas.
- **Sistema de palavra proibida** – Todo dia, uma palavra aleatória da língua portuguesa será escolhida. Se alguém digitá-la, receberá um castigo de **1 minuto** _(duração sujeita a mudanças)_.
- **`/pdd`** _(Admin only)_ – Exibe a palavra proibida do dia.

🏀 **Notificações Esportivas:**
- **Aviso automático de jogo do Botafogo** – Especialmente para a Bilau, já que ela tem **fogo no rabito**. 🔥

### ❌ Removido
- **Suporte a comandos prefixados** (`!comando`, `foa!comando`) – Agora é só na base do slash.